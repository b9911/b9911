# Source snapshot / Orbital Apiary

Project: csv-workbench. Curated for @b9911, an explicitly fictional developer persona.

Original source HEAD: `ce56b65b0084c527d658a4231917f4fda608834c`. The existing README and LICENSE are preserved. Windows Explorer desktop.ini files are omitted from this distributable. Added synthetic examples are in examples/profile-mission.

Runtime: Python 3.11+. Start: `python app.py`. Demo check: `python examples/profile-mission/check.py`.

This source download is for trying the application. It excludes .git and commit emails. A separately published repository should use the original project's history.
