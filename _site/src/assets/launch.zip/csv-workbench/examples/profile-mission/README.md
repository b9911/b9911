# Orbital Apiary — a runnable example

This is synthetic demonstration data for csv-workbench, curated for the explicitly fictional @b9911 developer persona.

## Try it

Requires Python 3.11+. From the project root run:

```text
python examples/profile-mission/check.py
```

Open input.csv in CSV Workbench, enable trimming and exact deduplication, then compare the exported CSV with cleaned.csv.

Start the full local app using Start.cmd on Windows, or `python app.py`; open http://127.0.0.1:8802. The original README contains its complete instructions.

## A useful next change

Add a second synthetic fixture with a quoted multiline note and describe the expected result.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.
