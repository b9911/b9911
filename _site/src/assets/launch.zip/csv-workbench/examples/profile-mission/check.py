from pathlib import Path
import json
import sys
folder = Path(__file__).resolve().parent
sys.path.insert(0, str(folder.parents[1]))
from app import clean_csv
result = clean_csv({"text": (folder / "input.csv").read_text(encoding="utf-8"), "trim": True, "dedup": True})
assert result["preview"] == [["sku", "name", "quantity"], ["0012", "Solar relay", "7"], ["0042", "Moon beacon", "3"]]
assert result["report"]["duplicates_removed"] == 1
(folder / "cleaned.csv").write_text(result["csv"], encoding="utf-8", newline="")
summary = {"facts": [["2", "data records"], ["1", "duplicate removed"], ["0012", "identifier preserved"]], "recordIds": ["0012", "0042"]}
(folder / "result.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print("PASS: CSV mission — duplicate removed; leading zeros preserved.")
